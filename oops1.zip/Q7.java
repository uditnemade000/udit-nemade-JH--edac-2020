import java.util.Scanner;
class Sub
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
int[] x=new int [5];
int sum=0;
System.out.println("enter the subject");
for (int i=0;i<5;i++)
{
x[i]=sc.nextInt();
}
for(int element:x)
{   
System.out.print(element);
}
for (int i=0;i<x.length;i++)
{
   sum=sum+x[i];
   System.out.print(sum);
   }
System.out.println();
double percent=((double)sum/500)*100;
System.out.print(percent+"%");
}
}
