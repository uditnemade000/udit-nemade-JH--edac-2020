class dcast
{
    public static void main(String args[])
    {
        byte c;
        short a=50, b=30;
        c=(byte)(a+b);
      System.out.println("The sum of 2 byte variable is="+c);  
        
       
        
    }
}