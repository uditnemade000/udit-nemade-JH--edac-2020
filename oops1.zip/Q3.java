class expre
{
  public static void main(String args[])
  {
      int x=2;
      int y;
      y =x*x+3*x-7;
          System.out.println("value of x="+x+" "+"value of y="+y);
      y= x++ + ++x;
          System.out.println("value of x="+x+" "+"value of y="+y);
      int z;
      z= x++ - --y - --x + x++; 
          System.out.println("value of x="+x+" "+"value of y="+y+" "+"value of z="+z);
      boolean b, c=true,d=false;
      b= c && d || !(c||d);
          System.out.println("value of c="+c+" "+"value of d="+d+" "+"value of b="+b);
  
   
 }   
}  
  
  