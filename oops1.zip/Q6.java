import java.util.Scanner;
class circle
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the radius of circle");
        int r=sc.nextInt();
        double ar=(3.14*r*r);
        double cr=(2*3.14*r);
        System.out.println("Area of circle is="+ar);
        System.out.println("Circumference of the circle is="+cr);
    }
}