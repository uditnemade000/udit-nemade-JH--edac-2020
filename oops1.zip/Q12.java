import java.util.Scanner;
class salari
{
    public static void main(String args[])
    {
    Scanner sc =new Scanner(System.in);
    System.out.println("Enter basic salary of employ");
    double n=sc.nextInt();
    if(n<10000)
    { 
        double Hra=(n*(10.00/100));
        double Da=(n*(90.00/100));
        double GS=(n+Hra+Da);
        System.out.print("Gross salary of employee="+GS);
        
    }
    else if (n>=10000)
            {
        double Hra=(2000);
        double Da=(n*(98.00/100));
        double GS=(n+Hra+Da);
        System.out.println("Gross salary of employee="+GS);
          
            }
    
}
}