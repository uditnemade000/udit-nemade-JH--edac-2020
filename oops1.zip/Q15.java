import java .util.*;
public class marriage 
{
    public static void main(String[] args)
    {
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter Gender = ");
     char gender=sc.next().charAt(0);

      System.out.println("Enter Age = ");
      int age=sc.nextInt();

      if((gender=='M' ||gender=='m')&&(age>=21)) 
       {
      System.out.println(" you are elegibale for marriage"); 
       }
      else if((gender=='F' ||gender=='f')&&(age>=18))
      {
      System.out.println("you are elegibale for marriage");
       }
      else
        {System.out.println("sorry you are not elegibale for marriage");}
       
    }
    
}
