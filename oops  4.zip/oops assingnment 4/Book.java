2)WAP to define a class Book with attributes id, name , 
	price accept data for 5 objects display book with highest price.*/





import java.util.Scanner;

class Book{
    Scanner input = new Scanner(System.in);
    int bookid,price;
    String name;
        void getdata()
        {
            System.out.println("Enter the Name of book");
            name=input.nextLine();
            System.out.println("Enter the Book Id");
            bookid=input.nextInt();
            System.out.println("Enter the Price");
            price=input.nextInt();
        }

}
public class BookDemo{

    void compare(Book b1,Book b2,Book b3)
    {
        if (b1.price>b2.price && b1.price>b3.price)
        {
            System.out.println("Book with highest price: "+b1.name);

        }else if(b2.price>b3.price)
        {
            System.out.println("Book with highest price: "+b2.name);
        }else
        {
            System.out.println("Book with highest price: "+b3.name);
        }

    }

    public static void main(String[] args) {
        Book b1= new Book();
        b1.getdata();
        Book b2=new Book();
        b2.getdata();
        Book b3 = new Book();
        b3.getdata();

        BookDemo demo=new BookDemo();

        demo.compare(b1,b2,b3);

    }

}
