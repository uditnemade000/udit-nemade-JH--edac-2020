1)WAP to define a class Student with attributes rollno, name , 
	marks accept data for 2 objects and display them.

class Student
{
	int rollno;
	String name;
	int marks;
	void display()
	{
		System.out.println("RollNo:"+rollno);
		System.out.println("Name:"+name);
		System.out.println("Marks:"+marks);
	}
	public static void main(String args[])
	{	
		
		Student stud1 = new Student();
		stud1.name="udit";
		stud1.rollno=1;
		stud1.marks=89;
		stud1.display();
		Student stud2 = new Student();
		stud2.name = "Raju";
		stud2.rollno = 2;
		stud2.marks=99;
		stud2.display();
	}
}
		

