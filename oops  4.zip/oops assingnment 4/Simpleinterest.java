

5)WAP to define Class Simpleinterest with attributes principalamount, 
	 rate of interest static ,number of years calculate SI and display it. 



class Simpleinterest
{
	
		int principalAmount;
		static double rateOfInterest;
		int numberOfYears;
		double interest=0;

		void Interest()
		{	
			this.interest = (this.principalAmount * rateOfInterest * this.numberOfYears)/100;
			System.out.println("Interest is:"+this.interest);
		}
}

class SimpleInterestDemo
{
	public static void main(String args[])
	{
		Simpleinterest si = new Simpleinterest();
		si.principalAmount=100;
		Simpleinterest.rateOfInterest=5.2;
		si.numberOfyears=3;
		si.Interest();
	}
}
		

}
		
