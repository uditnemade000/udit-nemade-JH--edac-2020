package Question;

import java.util.Scanner;

public class Ass05 {
	
	
	    
	    
	    public static void main(String[] args)  
	    { 
	       Scanner sc=new Scanner(System.in);
	       System.out.println("enter the any floating number");
	       float x =sc.nextFloat();
	       sc.close();
	       int count=0;
	       do
	       {
	    	   x =x*10;
	    	   count++;
	    	   
	       }
	       while(x !=(int)x);
	       System.out.println("Digit after decimal is:"+count);
	    } 
	} 
	  
	